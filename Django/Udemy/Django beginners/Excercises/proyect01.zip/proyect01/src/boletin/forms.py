from django import forms
#Importamos el modelo Registrado
from .models import Registrado

#Agregamos clase RegModelForm
class RegModelForm(forms.ModelForm):
    class Meta:
        model = Registrado
       #Los campos que se deseen mostar
        fields = ["nombre", "email"]

    def clean_email(self):
        email = self.cleaned_data.get("email")
        email_base, proveedor = email.split("@")
        dominio, extension = proveedor.split(".")
        if not extension == "edu":
            raise forms.ValidationError("Por favor ingrese un correo con extension .EDU")
        return email
#Formulario de Registro
class RegForm(forms.Form):
    nombre = forms.CharField(max_length = 100)
    email = forms.EmailField()
#Formulario de Contacto
class ContactForm(forms.Form):
    nombre = forms.CharField(required=False)
    email = forms.EmailField()
    mensaje = forms.CharField(widget=forms.Textarea)
