from django.contrib import admin
# Register your models here.
from .models import Registrado
# Importar modelo RegModelForm
from .forms import RegModelForm

class AdminRegistrado(admin.ModelAdmin):
    # Los registros que seran mostrados
    list_display = ["email", "nombre", "timestamp"]
    form = RegModelForm
    # Aparece link sobre el nombre para acceder al registro
    # NOTA: es importante que el campo contenga datos para que el link funcione
    #list_display_links = ["nombre"]
    # Filtros de registros
    list_filter = ["timestamp"]
    # Los registros que pueden ser modificados
    list_editable = ["nombre"]
    # Busqueda de campos
    search_fields = ["email", "nombre"]
    #class Meta:
    #    model = Registrado

admin.site.register(Registrado, AdminRegistrado)
