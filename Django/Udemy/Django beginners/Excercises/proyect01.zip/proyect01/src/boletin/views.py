#importamos renderizar
from django.shortcuts import render
#Importación de configuración para correo electrónico
from django.conf import settings
from django.core.mail import send_mail
#Importamos el formulario
from .forms import RegForm, RegModelForm, ContactForm
#Importamos el modelo de la base de datos llamado Registrado
from .models import Registrado
# Create your views here.
def inicio(request):
    #Contexto
    titulo = "Bienvenidos"
    #Request que extraera variables del sistem
    if request.user.is_authenticated:
        titulo = "Bienvenido %s" %(request.user)

    form = RegModelForm(request.POST or None)
    #Movemos el contexto para que se ejecute el de abajo
    context = {
                #variable que cargara el informe contexto
                "titulo": titulo,
                "el_form": form,
            }

    if form.is_valid():
        instance = form.save(commit=False)
        nombre = form.cleaned_data.get("nombre")
        email = form.cleaned_data.get("email")
        # En caso de la descripcion de persona no se llene por formulario
        if not instance.nombre:
            instance.nombre = "Persona nueva"
        #Grabar instancia
        instance.save()
        #Envio de nuevo contexto con nombre
        context = {
            "titulo": "Gracias %s!" %(nombre)
        }
        #Envio de nuevo contexto con email, el nombre de persona esta vacio
        if not nombre:
            context = {
                "titulo": "Gracias %s" %(email)
            }

        #Para mostrarse al cargar el browser
        #print(instance)
        #print(instance.timestamp)

    #    form_data = form.cleaned_data
    #    var1 = form_data.get("email")
    #    var2 = form_data.get("nombre")
    #    obj = Registrado.objects.create(email=var1, nombre=var2)

    #return render(request, "base.html", context)
    # Si el usuario esta autenticado se podra mostrar el Queryset
    if request.user.is_authenticated and request.user.is_staff:
        #Carga los datos hacia variable queryset
        queryset = Registrado.objects.all()
        #Comprobacion de los datos desde el queryset
        for instancia in queryset:
            print(instancia)
        context = {
            "queryset": queryset,
        }
    return render(request, "inicio.html", context)

def contacto(request):
    #Contexto
    titulo = "Contacto"

    form = ContactForm(request.POST or None)
    if form.is_valid():
        form_email = form.cleaned_data.get("email")
        form_nombre = form.cleaned_data.get("nombre")
        form_mensaje = form.cleaned_data.get("mensaje")
        asunto = "Form de Contaco"
        email_from = settings.EMAIL_HOST_USER
        email_to = [email_from, "ivanromanv@gmail.com"]
        email_mensaje = "%s: %s enviado por %s" %(form_nombre, form_email, form_mensaje)
        send_mail(asunto,
            email_mensaje,
            email_from,
            email_to,
            fail_silently=False,
            )
        #Forma 3 de llenar
        #for key, value in form.cleaned_data.items():
        #   print(key, value)
        #Forma 2 de llenar
        #for key in form.cleaned_data:
        #   print(key)
        #    print(form.cleaned_data.get(key))
        #Forma 1 de llenar
        #nombre = form.cleaned_data.get("nombre")
        #email = form.cleaned_data.get("email")
        #mensaje = form.cleaned_data.get("mensaje")
        #print(nombre, email, mensaje)

    context = {
        "titulo": titulo,
        "contacto": form,
    }
    return render(request, "contacto.html", context)

def about(request):
    return render(request, "about.html", {})

def listado(request):
    # Si el usuario esta autenticado se podra mostrar el Queryset
    if request.user.is_authenticated and request.user.is_staff:#
        #Carga todos los datos hacia variable queryset
        #queryset = Registrado.objects.all()
        #Queryset con filtro ordenado
        #queryset = Registrado.objects.all().order_by("-timestamp")#.filter(nombre__iexact="iv")
        queryset = Registrado.objects.all().order_by("-timestamp") #.filter(nombre__iexact="iv")
        for instance in queryset:
            #print(instance)
            context = {
                "queryset": queryset,
            }
    else:
        return render(request, "listado.html", {})
    return render(request, "listado.html", context)
